// Wrapper class for the native WebSocket class
function DWebSocket(wsUri, protocols) {
	this.wsUri = wsUri;
	this.protocols = DWebSocket.resolveProtocols(protocols);
	this.webSocket = DWebSocket.create(this.wsUri);
}

// returns a list of strings
DWebSocket.resolveProtocols = function(protocol) {
	if (protocol instanceof Array) {
		return protocol;
	}
	if (typeof protocol == 'string') {
		return [protocol];
	}
	return ['DWebSocket Protocol'];
}

DWebSocket.create = function(wsUri) {
	var wsConstructor = DWebSocket.wsConstructor;
	if (!wsConstructor) {
		if (window.WebSocket) {
			wsConstructor = function(wsu) {
				return new WebSocket(wsu);
			}
		}
		else if (window.MozWebSocket) {
			wsConstructor = function(wsu) {
				return new MozWebSocket(wsu);
			}
		} else {
			wsConstructor = function() { return null; }
		}
		DWebSocket.wsConstructor = wsConstructor;
	}
	return wsConstructor.call(window, wsUri);
}

DWebSocket.normalizeEventType = function(eventType) {
	var et = eventType.toLowerCase();
	if (et.indexOf('on') != 0) {
		et = 'on' + et;
	}
	return et;
}

DWebSocket.transformData = function(data) {
	switch (data.constructor) {
		case Object:
			return JSON.stringify(data);
		case String:
		default:
			return data;
	}
}

DWebSocket.prototype.toString = function() {
	return '[DWebSocket ' + this.wsUri + ']';
}

//WebSocket.OPEN = 1
//WebSocket.CONNECTING = 0
//WebSocket.CLOSING = 2
//WebSocket.CLOSED = 3
DWebSocket.prototype.send = function(data) {
	if (this.webSocket && this.webSocket.readyState == window.WebSocket.OPEN) {
		this.webSocket.send(DWebSocket.transformData(data));
	}
	return this;
}

DWebSocket.prototype.close = function() {
	if (this.webSocket && this.webSocket.readyState == window.WebSocket.OPEN) {
		this.webSocket.close();
	}
	return this;
}

/**
 * Add event listener - supported event types are open, message, close and error
 * Executes the eventHandler in the scope of the wrapper instance
 * Allows a chainable coding style by returning this wrapper instance
 * @param eventType
 * @param eventHandler
 */
DWebSocket.prototype.on = function(eventType, eventHandler) {
	if (this.webSocket) {
		var thisObj = this;
		this.webSocket[DWebSocket.normalizeEventType(eventType)] = function(e) {
			eventHandler.call(thisObj, e);
		}
	}
	return this;
}