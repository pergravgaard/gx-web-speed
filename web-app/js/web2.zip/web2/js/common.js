window.common = window.common || {};

Object.extend(common, {
    
	out: function(msg) {
		if (window.out && document.getElementById('divMonitor')) {
			out(msg);
		}
	},
	/* some show/hide message methods - you can show modal, progress and message anyway you like, but you should call the corresponding hide method afterwards */
	showModalProgressMessage: function(msg, cfg) {
		g('modal').show();
		g('progress').addClass('modal').show();
		this.showMessage(cfg);
	},
	hideModalProgressMessage: function(cfg) {
		g('progress').removeClass('modal').hide();
		g('modal').hide();
		this.hideMessage(cfg);
	},
	showProgressMessage: function(msg, cfg) {
		g('progress').show();
		this.showMessage(cfg);
	},
	hideProgressMessage: function(cfg) {
		g('progress').hide();
		this.hideMessage(cfg);
	},
	showModalMessage: function(msg, cfg) {
		g('modal').show();
		this.showMessage(msg, cfg);
	},
	hideModalMessage: function(cfg) {
		g('modal').hide();
		this.hideMessage(cfg);
	},
	buildMessageHtml: function(msg, headline, iconClass) {
	    var cls = iconClass ? ' ' + iconClass : '';
		var htm = '<div class="message-icon' + cls + '"></div><h1 class="message-header">' + (headline || 'System message') + '</h1><div class="message-paragraph">' + msg + '</div>';
		return htm;
	},
	showMessage: function(msg, config) {
		var cfg = Object.extend({
			timeout: NaN,
			cls: 'has-messages',
			fadeIn: null // specify an (empty) object literal for fading
		}, config);
		var dEl = g('messages');
		dEl.addClass(cfg.cls);
		if (msg) {
			var htm = this.buildMessageHtml(msg, cfg.headline, cfg.iconClass);
			dEl.html(htm);
		}
		if (cfg.fadeIn) {
			dEl.fadeIn(cfg.fadeIn);
		} else {
			dEl.show();
		}
		if (cfg.timeout) {
			window.setTimeout(function() {
				common.hideMessage(cfg);
			}, cfg.timeout);
		}
	},
	hideMessage: function(config) {
		var cfg = Object.extend({
			cls: 'has-messages',
			fadeOut: null // specify an (empty) object literal for fading
		}, config);
		var dEl = g('messages');
		if (cfg.fadeOut) {
			dEl.fadeOut(Object.extend({
				complete: function() {
					this.html('').removeClass(cfg.cls);
				}
			}, cfg.fadeOut));
		} else {
			dEl.html('').hide();
		}
	},
	showWrongBrowserMessage: function () {
	    var browserWhiteList = "Safari & iOS Safari (6+)<br/>Internet Explorer (10+)<br/>Google Chrome (29+)<br/>Firefox (24+)<br/>Opera (18+)<br/>Android (Neets app 1.3.0+)";
	    
	    common.showModalMessage('The browser you are using is not supported by the Neets control system.</div><div class="message-paragraph">Please use one of the following browsers:<br/><br/>' + browserWhiteList, {
	        headline: 'Browser not supported',
	        iconClass: 'wrong-browser'
	    });
	},
	showEstablishingConnectionMessage: function() {
	    common.showModalMessage('We are establishing a connection to the control system. Please wait...</div><div class="message-paragraph">', {
	        headline: 'Connecting',
	        iconClass: 'connection'
	    });
	},
    showLostConnectionMessage: function() {
        common.showModalMessage('Sorry, we have lost connection to the control system, we are trying to reconnect.</div><div class="message-paragraph">Please check that cable or WiFi is connected correctly. Please contact your system administrator for further help.', {
            headline: 'Lost connection',
            iconClass: 'connection'
        });
    }
});