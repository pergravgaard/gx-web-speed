if (!window.DProgressBar) {
    throw new Error('DAppCache.js: You must load the file DProgressBar.js!');
}
// singleton
var dAppCache = {
    messages: {
        ondownloading: 'Downloading updates...',
        onprogress: 'Downloading {0} of {1} files...'
    },
    fireHandler: function(name, args) {
        if (typeof dAppCache[name] == 'function') {
            dAppCache[name].apply(dAppCache, args);
        }
    },
    filesCounter: 0,
    noOfCachedFiles: NaN, // set after loading/including this file
    progressBarId: '', // set after loading/including this file
    dProgressBar: null, // initialized on ready if progressBarId is set
    cache: window.applicationCache,
    // event listeners - this refers to dAppCache.cache (window.applicationCache)
    onchecking: function(e) {
        dAppCache.fireHandler("onChecking", [e]);
    },
    onnoupdate: function(e) {
        dAppCache.fireHandler("onNoUpdate", [e]);
    },
    ondownloading: function(e) {
        if (dAppCache.dProgressBar) {
            dAppCache.dProgressBar.start(dAppCache.messages['ondownloading']);
        }
        dAppCache.fireHandler("onDownloading", [e]);
    },
    onprogress: function(e) { // is called when another file has been downloaded
        var msg = "";
        var pct = 0;
        if (dAppCache.noOfCachedFiles == NaN)
        {
            msg = dLib.util.formatMessage(dAppCache.messages['onprogress'], [++dAppCache.filesCounter, 'X']);
        }
        else
        {
            msg = dLib.util.formatMessage(dAppCache.messages['onprogress'], [++dAppCache.filesCounter, dAppCache.noOfCachedFiles]);
            pct = Math.min(Math.round(100 * dAppCache.filesCounter / dAppCache.noOfCachedFiles), 100);
        }
        
        if (dAppCache.dProgressBar) {
            dAppCache.dProgressBar.update(pct, msg);
        }
        
        dAppCache.fireHandler("onProgress", [e]);
    },
    onupdateready: function(e) {
        if (dAppCache.dProgressBar) {
            dAppCache.dProgressBar.stop();
        }
        dAppCache.fireHandler("onUpdateReady", [e]);
    },
    oncached: function(e) {
        if (dAppCache.dProgressBar) {
            dAppCache.dProgressBar.stop();
        }
        dAppCache.fireHandler("onCached", [e]);
    },
    onobsolete: function(e) {
        dAppCache.fireHandler("onObsolete", [e]);
    },
    onerror: function(e) {
        dAppCache.fireHandler("onError", [e]);
    },
    refresh: function() {
//		switch (this.cache.status) {
//			case this.cache.UNCACHED: // 0
//				break;
//			case this.cache.IDLE: // 1
//				break;
//			case this.cache.CHECKING: // 2
//				break;
//			case this.cache.DOWNLOADING: // 3
//				break;
//			case this.cache.UPDATEREADY: // 4
//				break;
//			case this.cache.OBSOLETE: // 5
//				break;
//		}
        if (this.cache.status > 0) {
            this.cache.update();
            if (this.cache.status === this.cache.UPDATEREADY) {
                this.cache.swapCache();
            }
        }
    },
    init: function() {
        if (!this.cache) {
            return;
        }
        var eventTypes = 'checking,error,noupdate,downloading,progress,updateready,cached,obsolete'.split(',');
        var i = eventTypes.length;
        while (i--) {
            var eType = eventTypes[i];
            this.cache.addEventListener(eType, this['on' + eType], false);
        }
    },
    ready: function() {
        if (!this.cache) {
            return;
        }
        if (this.progressBarId) {
            this.dProgressBar = new DProgressBar(this.progressBarId).init();
        }
    }
};

dAppCache.init(); // must be done now - onDOMContentLoaded is too late

// save handler for possible removal later
dAppCache.onDOMReadyListener = addDOMReadyListener(function() {
    dAppCache.ready();
});
