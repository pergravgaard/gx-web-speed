var lastChangeDate = "02/19/2014 13:22:34";

var firstPress = true;

// Ajax default configuration
if (window.HttpRequest) {
	Object.extend(HttpRequest.defaultConfig, {
		    
	    counter: 0,
        
	    onBeforeSend: function(params, hr) {
	        //g('progress').show();
	    },
	    onTimeout: function(hr) { // default timeout in DAjax.js is 3000 ms
	        //g('progress').hide();
	        //common.showMessage('Request timed out', { timeout: 2000 }); // fades out after 5 secs

	        //out('AJAX Timeout: ' + this.config.counter);
		    
	        if (this.config.counter == 2) {
	            //The third time, we show a message.
	            common.showMessage('Request timed out', { timeout: 2000 }); // fades out after 3 secs
	            this.config.counter = 0;    //Reset counter
	        }
	        if (this.config.counter++ < 2) {
	            this.open().send(); //Resend
	        }

	    },
	    onComplete: function(e, hr) {
	        //g('progress').hide();
	        this.config.counter = 0;
	        //resetKeepAlive();   //Reset the keep alive timer when receiving data on HTTP requests.
	    },
	    onCompleteNotOk: function(e, hr) {
	        common.showMessage('Request failed', { timeout: 2000 });
	    }
	});
};


// mappings between HTML elements (id attribute) and hardware devices
var mappings = {
	id1: ['StackPreAmp1' ], id2: ['StackPreAmp1' ], id3: ['StackPreAmp1' ], id6: ['StackPreAmp2' ], id7: ['StackPreAmp2' ], id8: ['StackPreAmp2' ], id29: [], id32: [], id582: [], id583: [], id584: [], id585: [], id30: [], id31: [], id586: [], id587: [], id588: [], id589: [], id48: ['Stack1' ,'Stack3' ,'StackPreAmp2' ,'StackPreAmp1' ], id49: ['Stack2' ,'Stack3' ,'StackPreAmp2' ,'StackPreAmp1' ], id50: ['Stack5' ,'StackPreAmp2' ,'StackPreAmp1' ], id51: ['Stack2' ,'Stack4' ,'StackPreAmp2' ], id52: ['Stack2' ,'Stack4' ,'StackPreAmp2' ], id53: ['Stack5' ,'StackPreAmp2' ], id54: ['Stack1' ,'Stack3' ,'StackPreAmp2' ,'StackPreAmp1' ], id55: ['Stack2' ,'Stack4' ,'StackPreAmp2' ], id56: ['Stack1' ,'Stack3' ,'Stack4' ,'StackPreAmp1' ,'StackPreAmp2' ], id71: [], id72: ['Stack2' ,'Stack3' ,'StackPreAmp2' ,'StackPreAmp1' ], id73: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id74: ['Stack4' ,'StackPreAmp2' ], id75: ['Stack2' ,'Stack4' ,'StackPreAmp2' ], id76: ['StackPreAmp2' ], id77: ['Stack3' ,'StackPreAmp1' ,'StackPreAmp2' ], id78: ['Stack4' ,'StackPreAmp2' ], id79: ['Stack4' ,'StackPreAmp2' ,'StackPreAmp1' ], id64: ['Stack1' ], id65: ['Stack1' ], id66: ['Stack1' ], id68: ['Stack1' ], id69: ['Stack1' ], id89: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id90: [], id91: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id92: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id93: ['StackPreAmp2' ,'Stack4' ], id94: ['StackPreAmp2' ], id95: ['StackPreAmp1' ,'Stack3' ,'StackPreAmp2' ], id96: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id97: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack4' ], id98: ['Stack2' ], id99: ['Stack1' ], id100: ['Stack2' ], id101: ['Stack1' ], id102: ['Stack1' ], id113: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id114: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id115: [], id116: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id117: ['StackPreAmp2' ,'Stack2' ,'Stack4' ], id118: ['StackPreAmp2' ], id119: ['StackPreAmp1' ,'StackPreAmp2' ], id120: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id121: ['StackPreAmp2' ,'StackPreAmp1' ], id122: ['Stack5' ], id123: ['Stack5' ], id124: ['Stack5' ], id125: ['Stack5' ], id126: ['Stack5' ], id137: [], id138: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id139: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id140: [], id141: ['StackPreAmp2' ,'Stack2' ,'Stack4' ], id142: ['StackPreAmp2' ,'Stack4' ], id143: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id144: ['StackPreAmp2' ,'Stack4' ], id145: ['StackPreAmp1' ,'StackPreAmp2' ], id146: ['Stack1' ], id147: ['Stack1' ], id148: ['Stack1' ], id149: ['Stack1' ], id150: ['Stack1' ], id130: ['Stack1' ], id131: ['Stack1' ], id132: ['Stack1' ], id133: ['Stack1' ], id134: ['Stack1' ], id155: [], id156: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id157: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id158: ['StackPreAmp2' ,'Stack4' ], id159: [], id160: ['StackPreAmp2' ,'Stack4' ], id161: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id162: ['StackPreAmp2' ,'Stack4' ], id163: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack4' ], id164: ['Stack1' ], id165: ['Stack1' ], id166: ['Stack1' ], id167: ['Stack1' ], id168: ['Stack1' ], id172: ['Stack2' ], id173: ['Stack2' ], id174: ['Stack2' ], id175: ['Stack2' ], id176: ['Stack2' ], id180: [], id181: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id182: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id183: ['StackPreAmp2' ,'Stack4' ], id184: ['StackPreAmp2' ,'Stack2' ,'Stack4' ], id185: [], id186: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id187: ['StackPreAmp2' ], id188: ['StackPreAmp2' ,'StackPreAmp1' ], id189: ['Stack1' ], id190: ['Stack1' ], id191: ['Stack1' ], id192: ['Stack1' ], id193: ['Stack1' ], id197: ['Stack5' ], id198: ['Stack5' ], id199: ['Stack5' ], id200: ['Stack5' ], id201: ['Stack5' ], id204: [], id205: ['StackPreAmp2' ,'Stack2' ,'Stack4' ], id206: ['StackPreAmp2' ,'Stack4' ], id207: ['StackPreAmp2' ,'Stack4' ], id208: ['StackPreAmp2' ,'Stack4' ,'StackPreAmp1' ], id210: ['Stack1' ], id211: ['Stack1' ], id212: ['Stack1' ], id213: ['Stack1' ], id214: ['Stack1' ], id218: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id219: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id220: [], id221: ['StackPreAmp2' ,'StackPreAmp1' ], id222: ['Stack5' ], id223: ['Stack5' ], id224: ['Stack5' ], id225: ['Stack5' ], id226: ['Stack5' ], id229: ['StackPreAmp2' ], id230: [], id231: ['StackPreAmp2' ], id232: ['StackPreAmp2' ], id233: ['StackPreAmp2' ,'Stack4' ,'StackPreAmp1' ], id235: ['Stack2' ], id236: ['Stack2' ], id237: ['Stack2' ], id238: ['Stack2' ], id239: ['Stack2' ], id243: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id244: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id245: [], id246: ['StackPreAmp2' ,'StackPreAmp1' ], id247: ['Stack5' ], id248: ['Stack5' ], id249: ['Stack5' ], id250: ['Stack5' ], id251: ['Stack5' ], id254: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id255: ['Stack2' ,'Stack4' ], id256: [], id257: ['StackPreAmp2' ], id258: ['StackPreAmp1' ,'StackPreAmp2' ], id260: ['Stack5' ], id261: ['Stack5' ], id262: ['Stack5' ], id263: ['Stack5' ], id264: ['Stack5' ], id268: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id269: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id270: [], id271: ['StackPreAmp2' ,'StackPreAmp1' ], id272: ['Stack5' ], id273: ['Stack5' ], id274: ['Stack5' ], id275: ['Stack5' ], id276: ['Stack5' ], id280: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id281: [], id282: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id283: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id284: ['StackPreAmp2' ,'Stack4' ], id285: [], id286: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id287: ['StackPreAmp2' ], id288: ['StackPreAmp2' ,'Stack4' ,'StackPreAmp1' ], id289: ['Stack2' ], id290: ['Stack2' ], id291: ['Stack2' ], id292: ['Stack2' ], id293: ['Stack2' ], id297: ['Stack5' ], id298: ['Stack5' ], id299: ['Stack5' ], id300: ['Stack5' ], id301: ['Stack5' ], id305: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id306: [], id307: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id308: [], id309: ['StackPreAmp2' ,'Stack4' ], id310: ['StackPreAmp2' ,'Stack4' ], id311: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id312: ['StackPreAmp2' ,'Stack4' ], id313: ['StackPreAmp2' ,'StackPreAmp1' ], id314: ['Stack2' ], id315: ['Stack2' ], id316: ['Stack2' ], id317: ['Stack2' ], id318: ['Stack2' ], id322: ['Stack1' ], id323: ['Stack1' ], id324: ['Stack1' ], id325: ['Stack1' ], id326: ['Stack1' ], id330: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id331: [], id332: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id333: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id334: [], id335: ['StackPreAmp2' ,'Stack4' ], id336: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id337: ['StackPreAmp2' ,'Stack4' ], id338: ['StackPreAmp1' ,'StackPreAmp2' ], id339: ['Stack2' ], id340: ['Stack2' ], id341: ['Stack2' ], id342: ['Stack2' ], id343: ['Stack2' ], id347: ['Stack2' ], id348: ['Stack2' ], id349: ['Stack2' ], id350: ['Stack2' ], id351: ['Stack2' ], id385: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id386: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id387: ['StackPreAmp2' ,'StackPreAmp1' ], id388: [], id389: ['Stack2' ,'StackPreAmp2' ,'Stack4' ], id390: ['StackPreAmp2' ,'Stack4' ], id391: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id392: ['StackPreAmp1' ,'Stack4' ,'StackPreAmp2' ], id393: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id395: ['Stack1' ], id396: ['Stack1' ], id397: ['Stack1' ], id398: ['Stack1' ], id399: ['Stack1' ], id361: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id362: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id363: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id364: ['Stack1' ,'Stack4' ,'StackPreAmp2' ], id365: [], id366: ['Stack4' ,'StackPreAmp2' ], id367: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id368: ['StackPreAmp1' ,'Stack4' ,'StackPreAmp2' ], id369: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ], id371: ['Stack2' ], id372: ['Stack2' ], id373: ['Stack2' ], id374: ['Stack2' ], id375: ['Stack2' ], id409: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id410: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ], id411: ['StackPreAmp2' ,'StackPreAmp1' ], id412: ['StackPreAmp2' ,'Stack1' ,'Stack4' ], id413: ['StackPreAmp2' ,'Stack2' ,'Stack4' ], id414: [], id415: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack1' ,'Stack3' ], id416: ['StackPreAmp1' ,'StackPreAmp2' ], id417: ['StackPreAmp2' ,'StackPreAmp1' ], id419: ['Stack5' ], id420: ['Stack5' ], id421: ['Stack5' ], id422: ['Stack5' ], id423: ['Stack5' ], id440: [], id441: [], id442: [], id443: [], id444: [], id445: [], id446: [], id447: [], id448: ['StackPreAmp2' ,'Stack4' ], id450: [], id451: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack2' ,'Stack3' ,'Stack4' ], id452: ['StackPreAmp2' ,'StackPreAmp1' ,'Stack3' ,'Stack4' ], id465: ['StackPreAmp1' ,'Stack3' ,'Stack4' ,'StackPreAmp2' ], id468: ['StackPreAmp1' ], id469: ['StackPreAmp1' ], id470: ['StackPreAmp1' ], id473: ['Stack1' ], id474: ['Stack1' ], id475: ['Stack1' ], id476: ['Stack1' ], id477: ['Stack1' ], id471: [], id472: [], id594: [], id595: [], id596: [], id597: [], id492: [], id493: [], id494: [], id495: [], id496: [], id497: [], id498: [], id499: [], id500: ['StackPreAmp2' ,'Stack4' ], id501: ['Stack1' ,'Stack3' ,'Stack4' ,'StackPreAmp2' ,'StackPreAmp1' ], id502: [], id503: ['Stack3' ,'Stack4' ,'StackPreAmp2' ,'StackPreAmp1' ], id516: ['StackPreAmp1' ,'Stack3' ,'Stack4' ,'StackPreAmp2' ], id519: ['StackPreAmp1' ], id520: ['StackPreAmp1' ], id521: ['StackPreAmp1' ], id524: ['Stack2' ], id525: ['Stack2' ], id526: ['Stack2' ], id527: ['Stack2' ], id528: ['Stack2' ], id522: [], id523: [], id598: [], id599: [], id600: [], id601: [], id544: [], id545: [], id546: [], id547: [], id548: [], id549: [], id550: [], id551: [], id552: ['StackPreAmp2' ], id553: ['Stack1' ,'Stack3' ,'Stack4' ], id554: ['Stack2' ,'Stack3' ,'Stack4' ], id555: [], id568: ['StackPreAmp1' ,'StackPreAmp2' ], id571: ['StackPreAmp1' ], id572: ['StackPreAmp1' ], id573: ['StackPreAmp1' ], id576: ['Stack5' ], id577: ['Stack5' ], id578: ['Stack5' ], id579: ['Stack5' ], id580: ['Stack5' ], id574: [], id575: [], id590: [], id591: [], id592: [], id593: []
};


function initTimerButtons() {
    DTimerButton.destroyAll(); // first destroy all previous instances
    // then find all elements that acts as a timer button in active page and master page
    q('.page.active .element, .masterpage .element').forEach(function(el, i) {
        if (el.id in mappings) {
            var cfg = Object.inheritFrom(buttons.sharedTimerConfig);
            cfg.devices = mappings[el.id];
            DTimerButton.newInstance(el.id, cfg).init();
        }
    });
}

// buttons singleton object for handling events on buttons and updating their states
var buttons = {
    all: ['id1', 'id2', 'id3', 'id6', 'id7', 'id8', 'id29', 'id32', 'id582', 'id583', 'id584', 'id585', 'id30', 'id31', 'id586', 'id587', 'id588', 'id589', 'id48', 'id49', 'id50', 'id51', 'id52', 'id53', 'id54', 'id55', 'id56', 'id71', 'id72', 'id73', 'id74', 'id75', 'id76', 'id77', 'id78', 'id79', 'id64', 'id65', 'id66', 'id68', 'id69', 'id89', 'id90', 'id91', 'id92', 'id93', 'id94', 'id95', 'id96', 'id97', 'id98', 'id99', 'id100', 'id101', 'id102', 'id113', 'id114', 'id115', 'id116', 'id117', 'id118', 'id119', 'id120', 'id121', 'id122', 'id123', 'id124', 'id125', 'id126', 'id137', 'id138', 'id139', 'id140', 'id141', 'id142', 'id143', 'id144', 'id145', 'id146', 'id147', 'id148', 'id149', 'id150', 'id130', 'id131', 'id132', 'id133', 'id134', 'id155', 'id156', 'id157', 'id158', 'id159', 'id160', 'id161', 'id162', 'id163', 'id164', 'id165', 'id166', 'id167', 'id168', 'id172', 'id173', 'id174', 'id175', 'id176', 'id180', 'id181', 'id182', 'id183', 'id184', 'id185', 'id186', 'id187', 'id188', 'id189', 'id190', 'id191', 'id192', 'id193', 'id197', 'id198', 'id199', 'id200', 'id201', 'id204', 'id205', 'id206', 'id207', 'id208', 'id210', 'id211', 'id212', 'id213', 'id214', 'id218', 'id219', 'id220', 'id221', 'id222', 'id223', 'id224', 'id225', 'id226', 'id229', 'id230', 'id231', 'id232', 'id233', 'id235', 'id236', 'id237', 'id238', 'id239', 'id243', 'id244', 'id245', 'id246', 'id247', 'id248', 'id249', 'id250', 'id251', 'id254', 'id255', 'id256', 'id257', 'id258', 'id260', 'id261', 'id262', 'id263', 'id264', 'id268', 'id269', 'id270', 'id271', 'id272', 'id273', 'id274', 'id275', 'id276', 'id280', 'id281', 'id282', 'id283', 'id284', 'id285', 'id286', 'id287', 'id288', 'id289', 'id290', 'id291', 'id292', 'id293', 'id297', 'id298', 'id299', 'id300', 'id301', 'id305', 'id306', 'id307', 'id308', 'id309', 'id310', 'id311', 'id312', 'id313', 'id314', 'id315', 'id316', 'id317', 'id318', 'id322', 'id323', 'id324', 'id325', 'id326', 'id330', 'id331', 'id332', 'id333', 'id334', 'id335', 'id336', 'id337', 'id338', 'id339', 'id340', 'id341', 'id342', 'id343', 'id347', 'id348', 'id349', 'id350', 'id351', 'id385', 'id386', 'id387', 'id388', 'id389', 'id390', 'id391', 'id392', 'id393', 'id395', 'id396', 'id397', 'id398', 'id399', 'id361', 'id362', 'id363', 'id364', 'id365', 'id366', 'id367', 'id368', 'id369', 'id371', 'id372', 'id373', 'id374', 'id375', 'id409', 'id410', 'id411', 'id412', 'id413', 'id414', 'id415', 'id416', 'id417', 'id419', 'id420', 'id421', 'id422', 'id423', 'id440', 'id441', 'id442', 'id443', 'id444', 'id445', 'id446', 'id447', 'id448', 'id450', 'id451', 'id452', 'id465', 'id468', 'id469', 'id470', 'id473', 'id474', 'id475', 'id476', 'id477', 'id471', 'id472', 'id594', 'id595', 'id596', 'id597', 'id492', 'id493', 'id494', 'id495', 'id496', 'id497', 'id498', 'id499', 'id500', 'id501', 'id502', 'id503', 'id516', 'id519', 'id520', 'id521', 'id524', 'id525', 'id526', 'id527', 'id528', 'id522', 'id523', 'id598', 'id599', 'id600', 'id601', 'id544', 'id545', 'id546', 'id547', 'id548', 'id549', 'id550', 'id551', 'id552', 'id553', 'id554', 'id555', 'id568', 'id571', 'id572', 'id573', 'id576', 'id577', 'id578', 'id579', 'id580', 'id574', 'id575', 'id590', 'id591', 'id592', 'id593'],
	mouseup: ['id1', 'id2', 'id3', 'id6', 'id7', 'id8', 'id29', 'id32', 'id582', 'id583', 'id584', 'id585', 'id30', 'id31', 'id586', 'id587', 'id588', 'id589', 'id48', 'id49', 'id50', 'id51', 'id52', 'id53', 'id54', 'id55', 'id56', 'id71', 'id72', 'id73', 'id74', 'id75', 'id76', 'id77', 'id78', 'id79', 'id64', 'id65', 'id66', 'id68', 'id69', 'id89', 'id90', 'id91', 'id92', 'id93', 'id94', 'id95', 'id96', 'id97', 'id98', 'id99', 'id100', 'id101', 'id102', 'id113', 'id114', 'id115', 'id116', 'id117', 'id118', 'id119', 'id120', 'id121', 'id122', 'id123', 'id124', 'id125', 'id126', 'id137', 'id138', 'id139', 'id140', 'id141', 'id142', 'id143', 'id144', 'id145', 'id146', 'id147', 'id148', 'id149', 'id150', 'id130', 'id131', 'id132', 'id133', 'id134', 'id155', 'id156', 'id157', 'id158', 'id159', 'id160', 'id161', 'id162', 'id163', 'id164', 'id165', 'id166', 'id167', 'id168', 'id172', 'id173', 'id174', 'id175', 'id176', 'id180', 'id181', 'id182', 'id183', 'id184', 'id185', 'id186', 'id187', 'id188', 'id189', 'id190', 'id191', 'id192', 'id193', 'id197', 'id198', 'id199', 'id200', 'id201', 'id204', 'id205', 'id206', 'id207', 'id208', 'id210', 'id211', 'id212', 'id213', 'id214', 'id218', 'id219', 'id220', 'id221', 'id222', 'id223', 'id224', 'id225', 'id226', 'id229', 'id230', 'id231', 'id232', 'id233', 'id235', 'id236', 'id237', 'id238', 'id239', 'id243', 'id244', 'id245', 'id246', 'id247', 'id248', 'id249', 'id250', 'id251', 'id254', 'id255', 'id256', 'id257', 'id258', 'id260', 'id261', 'id262', 'id263', 'id264', 'id268', 'id269', 'id270', 'id271', 'id272', 'id273', 'id274', 'id275', 'id276', 'id280', 'id281', 'id282', 'id283', 'id284', 'id285', 'id286', 'id287', 'id288', 'id289', 'id290', 'id291', 'id292', 'id293', 'id297', 'id298', 'id299', 'id300', 'id301', 'id305', 'id306', 'id307', 'id308', 'id309', 'id310', 'id311', 'id312', 'id313', 'id314', 'id315', 'id316', 'id317', 'id318', 'id322', 'id323', 'id324', 'id325', 'id326', 'id330', 'id331', 'id332', 'id333', 'id334', 'id335', 'id336', 'id337', 'id338', 'id339', 'id340', 'id341', 'id342', 'id343', 'id347', 'id348', 'id349', 'id350', 'id351', 'id385', 'id386', 'id387', 'id388', 'id389', 'id390', 'id391', 'id392', 'id393', 'id395', 'id396', 'id397', 'id398', 'id399', 'id361', 'id362', 'id363', 'id364', 'id365', 'id366', 'id367', 'id368', 'id369', 'id371', 'id372', 'id373', 'id374', 'id375', 'id409', 'id410', 'id411', 'id412', 'id413', 'id414', 'id415', 'id416', 'id417', 'id419', 'id420', 'id421', 'id422', 'id423', 'id440', 'id441', 'id442', 'id443', 'id444', 'id445', 'id446', 'id447', 'id448', 'id450', 'id451', 'id452', 'id465', 'id468', 'id469', 'id470', 'id473', 'id474', 'id475', 'id476', 'id477', 'id471', 'id472', 'id594', 'id595', 'id596', 'id597', 'id492', 'id493', 'id494', 'id495', 'id496', 'id497', 'id498', 'id499', 'id500', 'id501', 'id502', 'id503', 'id516', 'id519', 'id520', 'id521', 'id524', 'id525', 'id526', 'id527', 'id528', 'id522', 'id523', 'id598', 'id599', 'id600', 'id601', 'id544', 'id545', 'id546', 'id547', 'id548', 'id549', 'id550', 'id551', 'id552', 'id553', 'id554', 'id555', 'id568', 'id571', 'id572', 'id573', 'id576', 'id577', 'id578', 'id579', 'id580', 'id574', 'id575', 'id590', 'id591', 'id592', 'id593'],
	timeoutIds: {},
	releaseTimeout: 300,
	
	buttonDown: function(e) {
        //out(e.type)

        var id = this.id;

        if (firstPress) {
            //out('firstPress: ' + e.type);
            switch (e.type) {
                case "mousedown":
                case "mouseup":
                {
                    //Remove touch event handlers.
                    //out('Remove touch events');
                    buttons.all.forEach(function (id) {
                        g(id).off('touchstart', buttons.buttonDown).off('touchend', buttons.buttonUp).off('touchcancel', buttons.buttonUp);
                    });
                    break;
                }
                case "touchstart":
                case "touchend":
                case "touchcancel":
                {
                    //Remove mouse event handlers.
                    //out('Remove mouse events');
                    buttons.all.forEach(function (id) {
                        g(id).off('mousedown', buttons.buttonDown).off('mouseup', buttons.buttonUp);
                    });
                    break;
                }
            }

            firstPress = false;
        }

        if (DElement.attr(this, "data-empty-button")) {
            return; //Button has no function, so dont handle it.
        }

        if (DElement.attr(this, 'data-disabled')) {
            return;
        }

        DElement.addClass(this, 'pressed', false);
        DElement.setAttribute(this, 'data-pressed', true);
        //var dTimerButton = DTimerButton.instances[this.getAttribute('data-timer-button-index')];
        var dTimerButton = DTimerButton.instances[this.getAttribute('id')]; // DTimerButton.instances is a map, not a list
        if (dTimerButton) { // do not believe this check is necessary any longer
            dTimerButton.start(true); // important to pass an argument - otherwise the onBeforeStart function will cause endless recursion
        }
		app.triggerStatus(id, 'KeyDown');
	},
	buttonUp: function(e) {
	
	    if(!DElement.attr(this, 'data-pressed')) {
	        return; //Do not allow button up if button down hasn't been fired.
	    }
	    
	    if (DElement.attr(this, "data-empty-button")) {
	        return; //Button has no function, so dont handle it.
	    }
	    
	    //Remove data-pressed
	    DElement.removeAttribute(this, 'data-pressed');
        
	    //Set the state of the buttons to the ones received in elementsResponse.

	    //out('Button up, set states.');
	    buttons.all.forEach(function(btnId) {
	        var elem = g(btnId);
	        
	        var currentState = elem.attr('data-new-state');  //Returns DElement if attr not existing.
	        if (currentState == elem)
	            currentState = null;
	        
	        if (currentState) {
	            elem.attr('class', 'element state' + currentState);
	            elem.removeAttribute('data-new-state');
	        }
	    });
	    
	    var id = this.id;
	    
	    DElement.removeClass(this, 'pressed');	//If Ajax response is received between down and up, the 'pressed' class probably doesn't exist.
	    
		if (buttons.mouseup.contains(id)) {
			app.triggerStatus(id, 'KeyUp');
		}

		
	},
	sharedTimerConfig: {
	    bindEvents: '', // disable start on click
	    progressType: 'pie', // 'pie' or 'bar'  
	    progressPieConfig: {
	        fill: false,
	        showMessage: false
	    },
	    progressBarConfig: {
			
	    },
        onBeforeStart: function() {
            // important to query for more than one argument, otherwise we get endless recursion
            if (arguments.length == 2 && this.config.devices && this.config.devices.length) {
                var devices = this.config.devices;
                for (var id in DTimerButton.instances) {
                    var dTimerButton = DTimerButton.instances[id];
                    if (dTimerButton !== this) {
                        for (var i = 0, l = dTimerButton.config.devices.length; i < l; i++) {
                            var n = dTimerButton.config.devices[i];
                            if (devices.contains(n)) {
                                dTimerButton.start();
                                break;
                            }
                        }
                    }
                }
            }
        },
	    //callback: function() { out(this.dTimer.config.duration) },
		duration: 1500 // default for every timer button
	},
	getTimerButton: function(id) {
		return DTimerButton.instances[id];
	},
	configureTimerButton: function(dTimerButton, cfg) {
		if (dTimerButton) {
			dTimerButton.setTimerConfig(cfg);
		}
	},
    test: function(e) {
        out('test: ' + e.type)
    },
	onReady: function() {
	    this.all.forEach(function(id) {
			if ('onmousedown' in document.documentElement) {
                //g(id).on('mousedown', buttons.test).off('mousedown', buttons.test);
	            //Touch not supported. Hook up on mouse events.
				//out('Using mouse');
	            g(id).on('mousedown', buttons.buttonDown).on('mouseup', buttons.buttonUp);
	        }
			if ('ontouchstart' in document.documentElement) {
	            //Touch supported. Hook up on touch events.
				//out('Using touch');
	            g(id).on('touchstart', buttons.buttonDown).on('touchend', buttons.buttonUp).on('touchcancel', buttons.buttonUp);
	        }
	        
		    //DTimerButton.newInstance(id, buttons.sharedTimerConfig).init();
		});
	}
};

var webSocketKeepAliveTimer;	//The timer that keeps track of the websocket connection.
function webSocketKeepAliveTimerCallback() {
	//Now close the websocket connection and connect again.
    common.showLostConnectionMessage();
	connectWebSocket();
}
function resetKeepAlive() {
	if(webSocketKeepAliveTimer != null)
	{
		clearTimeout(webSocketKeepAliveTimer);
	}
	
	webSocketKeepAliveTimer = setTimeout(function(){webSocketKeepAliveTimerCallback()}, 15000);
}

// common app singleton object for handling Ajax & WebSocket communication
Object.extend(app, {

	// Ajax calls
	triggerStatus: function(id, paramName) {
		this.fetchStatus(id, paramName, false);
	},
	triggerStatusUpdate: function() {
	    this.fetchStatus(null, null, true);
	},
	fetchStatus: function(id, paramName, useResponse) {
		new HttpRequest({
			useResponse: !!useResponse,
			url: app.contextPath + ((paramName == null) ? '/status.json' : '/status.json?' + paramName + '=' + encodeURIComponent(id.replace('id', ''))),
			onCompleteOk: function(e, hr) {
				if (this.config.useResponse) {
					app.parseStatusResponse(hr.json);
				} else {
					// do nothing - websocket will notify when ready
				}
			}
		}).open().send();
	},
	fetchDevices: function() {
		new HttpRequest({
			url: app.contextPath + '/devices.json',
			onCompleteOk: function(e, hr) {
				app.parseDevicesResponse(hr.json);
			}
		}).open().send();
	},
	fetchElements: function() {
		new HttpRequest({
			url: app.contextPath + '/elements.json',
			onCompleteOk: function(e, hr) {
				app.parseElementsResponse(hr.json);
			}
		}).open().send();
	},
	// methods for parsing JSON responses
	parseStatusResponse: function(json) {
	    if (json == "") {
	        common.showMessage('Error in status response', { timeout: 5000 });
	        return;
	    }
	    var lastChangeDateJson = json['lastChangeDate'];
	    if(lastChangeDateJson != lastChangeDate)
	    {
	        //There is a change, so reload/cache website.
	        var href = app.contextPath + '/load.html';
	        location.href = href;
	    }
		var pageId = json['currentPage'];
		if (pageId && document.getElementById(pageId)) {
		    app.gotoPage(pageId);
		}
	},
	parseElementsResponse: function(json) {
	    if (json == "") {
	        common.showMessage('Error in elements response', { timeout: 5000 });
	        return;
	    }
		for (var id in json.Elements) {
			var v = json.Elements[id];
			//buttons.releaseState(id, true);
			var elem = g(id);
		    var newState = v['State'];
			
			elem.attr('data-new-state', newState);

			var isPressed = elem.attr("data-pressed");
		    if (isPressed == elem)
		        isPressed = null;
		    
		    if (isPressed)  //If button is pressed, then do not set the state yet. It is done in button up.
		    {
		        //out(id + " is pressed");
		    } else {
		        elem.attr('class', 'element state' + newState);
		    }

		    //Moved to button up: elem.attr('class', 'element state' + v['State']);
		}
	},
	parseDevicesResponse: function(json) {
	    if (json == "") {
	        common.showMessage('Error in devices response', { timeout: 5000 });
	        return;
	    }
		for (var id in mappings) {
			var deviceNames = mappings[id];
			var max = 0;
			for (var i = 0, l = deviceNames.length; i < l; i++) {
				var deviceName = deviceNames[i];
				var n = json[deviceName];
				max = Math.max(n, max);
			}
			//Only set progress if higher than 1 sec.
			if (max > 1) {
			    var dTimerButton = buttons.getTimerButton(id);

			    var newDuration = (max * 1000);// + 200;	//Adding 200 ms offset.
			    var remaining = dTimerButton.getRemaining();
			    
			    if (dTimerButton.isRunning())
			    {
			        //out("new: " + (newDuration) + "; old: " + dTimerButton.getDuration() + "; remaining: " + remaining);
			        
			        if ((newDuration) > remaining) {
			            var runTime = dTimerButton.getRunningTime();
			            //out("setDurationTo " + (newDuration + runTime));
			            dTimerButton.setDuration((newDuration+runTime), true);
			        }
			    }
			    else
			    { 
			        //out("isRunning: false; new: " + newDuration);
				    buttons.configureTimerButton(dTimerButton, {
					    duration: newDuration
				    });    
			    
			        dTimerButton.start();
			    }
			}
		}
	},
	parseWebSocketResponse: function(data) {
		// data should be a JSON parseable string with properties type and data where type is a string and data an object literal with properties time, text and author
		if (typeof data === 'string')
		{
		    
			if(data.indexOf('keepalive') > -1)
			{
				//We still got a connection running.
				resetKeepAlive();
			}
			else
			{
				if (data.indexOf('a') > -1) {
					app.fetchDevices();
				}
				if (data.indexOf('b') > -1) {
					app.fetchElements();
				}
				if (data.indexOf('c') > -1) {
					app.triggerStatusUpdate();
				}
			}
		}
	},
	initPage: function() {
		/*q('.button.goto').on('click', function(e) {
			e.preventDefault();
			var pageId = app.resolvePageId(this);
			app.gotoPage(pageId);
		});*/
        var page = q('.page.active:not(.bg)').item(0);
        this.gotoPage(page.id);
        // don't repeat code - the code below does the same as gotoPage
//		q('.pages .page').forEach(function(div, i) {
//			var dEl = g(div);
//			if (dEl.hasClass('active')) {
//			    if(dEl.hasClass('bg')) {
//			        dEl.show();	//If it is a background, then show as 'block'
//			    }
//			    else {
//			        dEl.show('table');	//If it is the content, then show as 'table'
//			    }
//			}
//			else {
//			    dEl.hide();
//			}
//		});
	},
	gotoPage: function(pageId) {
		q('.pages .page').forEach(function(div, i) {
			var dEl = g(div);
			if (div.id === pageId) {
			    dEl.addClass('active').show('table');	//If it is the content, then show as 'table'
                app.onPageLoad();
			}
			else if(div.id === (pageId+'_bg')){
			    dEl.addClass('active').show();	//If it is a background, then show as 'block'
			}
			else if (dEl.hasClass('active')) {
				dEl.removeClass('active').hide();
			}
		});
	},
    onPageLoad: function() {
        initTimerButtons();
        return;
        DTimerButton.destroyAll(); // first destroy all previous instances
        for (var device in app.deviceButtons) {
            var cssSelector = '';
            app.deviceButtons[device].forEach(function(id, i) {
                if (i) {
                    cssSelector += ',';
                }
                cssSelector += '.page.active #' + id + '.element';
            });
            out('size: '+q(cssSelector).size());
            DTimerButton.newInstance(cssSelector, buttons.sharedTimerConfig).init();
        }
        //out(DTimerButton.instances.length)
    },
	resolvePageId: function(el) {
		switch (el.tagName.toLowerCase()) {
			case 'a':
				var href = el.getAttribute('href');
				return href.substring(1);
			case 'button':
			case 'input':
				return el.value;
			default:
				break;
		}
		return '';
	}
});

function adjustDisplay() {
    var resolutions = { // defined resolutions
		'Tablet': [1024, 768]
	};
    var resList = [];
    for (var k in resolutions) {
        resList.push(resolutions[k]);
    }
    var reResolveResolutionOnOrientationChange = true;
    var bestResolution = app.bestResolution;
    if (!bestResolution || reResolveResolutionOnOrientationChange) {
        bestResolution = app.bestResolution = {};
        dScreen.resolveBestResolution(resList, bestResolution);
    }
    var pagesId = 'res' + bestResolution.width + 'x' + bestResolution.height;
    //out('pagesId:' + pagesId);
    if (document.getElementById('divBodyContainer')) {
        g('divBodyContainer').css({ width: bestResolution.width + 'px', height: bestResolution.height + 'px', display: 'block' }); // this is important for scaling to work!!
        q('.pages').forEach(function(el, i) {
            if (el.id == pagesId) {
                //out('show: ' + el.id);
                g(el).show();
            } else {
                //out('hide: ' + el.id);
                g(el).hide();
            }
        });
    } else {
        document.write('<style type="text/css">#' + pagesId + '{display:block;}#divBodyContainer{display:block;width:' + bestResolution.width + 'px;height:' + bestResolution.height + 'px;}</style>');
    }
    dScreen.scalePage([bestResolution.width, bestResolution.height]);
};
adjustDisplay();
(function() {
	// prevent scrolling - be careful here - make sure the user really can see, what he's supposed to!!
	if (document.addEventListener) {
		document.addEventListener('touchmove', function(e) { e.preventDefault(); }, false);
	};
	// Don't call the Android app as it may return the wrong width/height
//	if (window.Neets) { // shown in Android webview - Android JavaScriptInterface called Neets with methods GetScreenHeight and GetScreenWidth
//		dScreen.getScreenWidth = function() { var w = window.Neets.GetScreenWidth(); out(w); return w; };
//		dScreen.getScreenHeight = function() { return window.Neets.GetScreenHeight(); };
//	}

    dScreen.onOrientationChange = adjustDisplay;
	//Delay the orientation calculation.
    //dScreen.onOrientationChange = (function() { setTimeout(function() {
	//    out('before adjust');
	//    adjustDisplay();
	//    out('after adjust');
	//}, 0); });
    

})();

var isConnecting = false;
function connectWebSocket()
{
	if(isConnecting)
		return;
		
	WebSocketDisconnect();

	var url = 'ws://' + location.hostname + ':80';
	
	//var isSafariWin = (BrowserDetect.OS.indexOf('Win') != -1) && (BrowserDetect.browser.indexOf('Safari') != -1);
	//var isSafariMobile = (BrowserDetect.OS.indexOf('iOS') != -1) && (BrowserDetect.browser.indexOf('Safari') != -1);
	//out("ua: " + navigator.userAgent);
	var browser = BrowserDetect.browser;
	var ver = BrowserDetect.version;
	//out("browser: " + browser + ", version: " + ver);
        
	var isSafariUnsupported = (browser.indexOf('Safari') != -1 || browser.indexOf('iOS') != -1) && (ver < 6.0);
	var isIEUnsupported = (browser.indexOf('Explorer') != -1) && (ver < 10.0);
	var supportsWebSocket = window.Neets || window.WebSocket || window.MozWebSocket;

	if(isSafariUnsupported == false && isIEUnsupported == false && supportsWebSocket)
	{
		WebSocketConnect(url);
	}
	else
	{
	    common.showWrongBrowserMessage();
	}
}

function WebSocketOnMessage(data)
{
	//out('ws msg: ' + data);
	app.parseWebSocketResponse(data);
}
function WebSocketOnOpen()
{
	//out('ws open');
	//app.out('Connected to ' + this.wsUri);
	
	var index = navigator.userAgent.indexOf('/');
	var username = index > -1 ? navigator.userAgent.substring(0, index) : navigator.userAgent;
	WebSocketSend(username);
	
	common.hideModalMessage();
	
	isConnecting = false;	//Reset variable before connecting again.
	resetKeepAlive();	//Reset timer.
}
function WebSocketOnClose(code, reason)
{
	out('ws close: ' + code + ', ' + reason);
	
	isConnecting = false;	//Reset variable before connecting again.
    
	if (code == 4) {
	    out("CODE 4");
	    connectWebSocket(); //In Android app an error code 4 can occur, when awaken from sleep.
	}   
    
	resetKeepAlive();	//Reset timer.
}
function WebSocketSend(data)
{
	out('ws send: ' + data);
	if(window.dWebSocket)
	{
		window.dWebSocket.send(data); // you can send object literals as well (fx {msg: 'HTML5 WebSocket rocks!'}) - will be converted to JSON by DWebSocket.js
	}
	else if(window.Neets)
	{
		//Android app
		window.Neets.WebSocketSend(data);
	}
}
function WebSocketConnect(url)
{
	isConnecting = true;	//Set to true, so we don't get two simultanous connecting attempts.
	if(window.Neets && BrowserDetect.OS.indexOf('Android') != -1)
	{
		out('IsAndroidWS');
		//Android app.
		window.Neets.WebSocketConnect(url);
	}
	else
	{
		window.dWebSocket = new DWebSocket(url);
		if (window.dWebSocket)
		{
			out('IsBrowserWS');
			window.dWebSocket.on('error', function(e)
			{
				out('ws error: ' + e.code);

				isConnecting = false;	//Reset variable before connecting again.
				resetKeepAlive();	//Reset timer.
			}).
			on('close', function(e)
			{
				// will be called if page is reloaded or websocket server closes connection
				WebSocketOnClose(e.code, e.reason);
			}).
			on('message', function(e)
			{
				WebSocketOnMessage(e.data);
				
			}).on('open', function(e)
			{
				WebSocketOnOpen();
			});
			
			resetKeepAlive();	//Reset timer.
		}
		else if (!window.Neets) {
			
		    common.showWrongBrowserMessage();
		}
	}
}
function WebSocketDisconnect()
{
	if(window.dWebSocket != null)
	{
		window.dWebSocket.close(1001, '');	//1001=CLOSE_GOING_AWAY, The endpoint is going away, either because of a server failure or because the browser is navigating away from the page that opened the connection.
	}
	else if(window.Neets)
	{
		window.Neets.WebSocketDisconnect();
	}
}

//function regroupButtons() {
//    // group buttons by device
//    var deviceButtons = app.deviceButtons = {};
//    var usedButtonIds = [];
//    for (var btnId in mappings) {
//        var deviceIds = mappings[btnId];
//        for (var i = 0, l = deviceIds.length; i < l; i++) {
//            var devId = deviceIds[i];
//            if (!(devId in deviceButtons)) {
//                deviceButtons[devId] = [];
//            }
//            deviceButtons[devId].push(btnId);
////            if (!usedButtonIds.contains(btnId)) { // only assign each button once!
////                usedButtonIds.push(btnId);
////                deviceButtons[devId].push(btnId);
////            } else {
////                out('used: ' + btnId);
////            }
//        }
//    }
//}

domReady(function() {
    //regroupButtons(); // do not need to regroup after all
	buttons.onReady();
	app.initPage();
//	common.showEstablishingConnectionMessage();
//	connectWebSocket();
});